let vocales = ['a', 'e', 'i', 'o', 'u'];

for(let i=0 ; i < vocales.length; i++){

document.write(`${vocales[i]} <br>`);

}