let A, B;
A = 9;
B = 7;
resultado = A + B;
alert (`La suma de A+B es: ${resultado}`);
alert (`La diferencia de A-B es: ${A-B}`);
alert (`La multiplicación de AxB es: ${A*B}`);
alert (`La división de A/B es: ${resultado=A/B}`);