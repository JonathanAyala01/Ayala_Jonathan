let a, b;
a = 3; b = 7;
resultado = a * b;
document.write(`Variable a contiene ${a} <br> ` );
document.write(`Variable b contiene ${b} <br> ` );
document.write(`El producto de a por b es ${resultado} <br> `);
document.write( `Los puntos de interrupcion son fundamentales para
programar`);
