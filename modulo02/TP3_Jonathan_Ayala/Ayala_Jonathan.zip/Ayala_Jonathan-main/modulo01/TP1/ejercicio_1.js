document.writeln("Hola Mundo!");
// imprime por pantalla un saludo visualizada por el usuario 
