# Título: Curso de programación full stack
## Subtítulo: Comisión A o B según corresponda
#### Encabezado: Silicon Misiones - https://siliconmisiones.gob.ar/
*Autor: nombre y apellido del estudiante*
- Descripción: este repositorio fue creado con fines académicos. Contiene los ejercicios
resueltos del Módulo 1.
